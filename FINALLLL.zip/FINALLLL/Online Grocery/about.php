
<!DOCTYPE html>
<html>
<head>
<title>Grocery Store a Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | About Us :: w3layouts</title>
<body><?php
require 'dbcon.php';
require 'header.php';
?>
		<div class="w3l_banner_nav_right">
<!-- about -->
		<div class="privacy about">
			<h3>About Us</h3>
			Online Grocery System is a web-based e-commerce portal for buying and selling goods for day to day life. This project will be a web-based shopping system for an existing shop. The project objective is to deliver the online shopping activities through the use of internet. The project is an attempt to provide advantage of online shopping to the customer of the real shop. It helps buying the product from anywhere through the use of internet. This system can be implemented to any shop in the locality or in the wide range of shop having outlet chains. Talking about the system, the system is divided into two module admin and user module where admin have a full control over the system, admin can add, update and delete the products. Along with add and update category admin can view users information, accepts payments and process orders for the delivery.
			 Web user can browse various products available in the site and can process their order after the registration only. 
                      </p>
			<div class="agile_about_grids">
				<div class="col-md-6 agile_about_grid_right">
					<img src="images/31.jpg" alt=" " class="img-responsive" />
				</div>
				<div class="col-md-6 agile_about_grid_left">
					<ol>
						<li>fresh vegetables</li>
						<li>rice, dals, oil</li>
						<li> household cleaning items</li>
						<li>personal care products</li>
					</ol>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
<!-- //about -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->
<!-- team -->
	<div class="team">
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //team -->
<!-- testimonials -->
	<div class="testimonials">
		<div class="container">
			
				
		</div>
	</div>
<?php include 'footer.php'?>
</body>
</html>